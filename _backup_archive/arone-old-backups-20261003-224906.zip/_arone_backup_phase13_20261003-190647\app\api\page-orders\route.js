import crypto from 'node:crypto';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

function text(value, max = 500) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}

function integer(value, fallback, min, max) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.max(min, Math.min(max, Math.round(number)));
}

function requestIsSameOrigin(request) {
  const origin = request.headers.get('origin');
  if (!origin) return true;

  try {
    return origin === new URL(request.url).origin;
  } catch {
    return false;
  }
}

function getOrderBlock(content, blockId) {
  const blocks = Array.isArray(content) ? content : [];
  return blocks.find(
    (block) => block?.type === 'orderForm' && block?.id === blockId
  );
}

function orderNo() {
  const stamp = Date.now().toString(36).toUpperCase();
  const random = crypto.randomBytes(2).toString('hex').toUpperCase();
  return `AR-${stamp}-${random}`;
}

export async function POST(request) {
  try {
    if (!requestIsSameOrigin(request)) {
      return Response.json({ error: 'Invalid request origin.' }, { status: 403 });
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return Response.json({ error: 'Invalid request body.' }, { status: 400 });
    }

    const pageId = text(body?.pageId, 120);
    const blockId = text(body?.blockId, 160);
    const customer = body?.customer || {};

    // Honeypot spam field.
    if (text(customer.website, 200)) {
      return Response.json({ error: 'Invalid submission.' }, { status: 400 });
    }

    const customerName = text(customer.name, 100);
    const phone = text(customer.phone, 24);
    const email = text(customer.email, 160);
    const address = text(customer.address, 500);
    const city = text(customer.city, 100);
    const note = text(customer.note, 500);
    const zone = customer.zone === 'OUTSIDE' ? 'OUTSIDE' : 'DHAKA';

    if (!pageId || !blockId) {
      return Response.json({ error: 'Page information is missing.' }, { status: 400 });
    }

    if (!customerName || !phone || !address || !city) {
      return Response.json(
        { error: 'Name, phone, city and address are required.' },
        { status: 400 }
      );
    }

    const phoneDigits = phone.replace(/\D/g, '');
    if (phoneDigits.length < 8 || phoneDigits.length > 15) {
      return Response.json({ error: 'Please enter a valid phone number.' }, { status: 400 });
    }

    const page = await prisma.page.findFirst({
      where: {
        id: pageId,
        status: 'PUBLISHED',
      },
      select: {
        id: true,
        title: true,
        slug: true,
        pageType: true,
        content: true,
      },
    });

    if (!page) {
      return Response.json({ error: 'This order page is not available.' }, { status: 404 });
    }

    const block = getOrderBlock(page.content, blockId);
    if (!block) {
      return Response.json({ error: 'Order form configuration was not found.' }, { status: 400 });
    }

    const allowedProductIds = Array.isArray(block.productIds)
      ? [...new Set(block.productIds.map(String))].slice(0, 8)
      : [];

    const requested = Array.isArray(body?.items) ? body.items.slice(0, 8) : [];
    const quantityById = new Map();

    for (const item of requested) {
      const productId = text(item?.productId, 120);
      if (!productId || !allowedProductIds.includes(productId)) continue;

      const quantity = integer(item?.quantity, 0, 0, 20);
      if (quantity > 0) quantityById.set(productId, quantity);
    }

    const ids = [...quantityById.keys()];
    if (!ids.length) {
      return Response.json({ error: 'Please select at least one product.' }, { status: 400 });
    }

    const products = await prisma.product.findMany({
      where: {
        id: { in: ids },
        active: true,
      },
      select: {
        id: true,
        name: true,
        price: true,
        stock: true,
      },
    });

    if (products.length !== ids.length) {
      return Response.json(
        { error: 'One or more selected products are unavailable.' },
        { status: 409 }
      );
    }

    const orderItems = [];
    let subtotal = 0;

    for (const product of products) {
      const quantity = quantityById.get(product.id) || 0;

      if (product.stock <= 0 || quantity > product.stock) {
        return Response.json(
          { error: `${product.name} does not have enough stock.` },
          { status: 409 }
        );
      }

      const lineTotal = product.price * quantity;
      subtotal += lineTotal;

      orderItems.push({
        productId: product.id,
        name: product.name,
        unitPrice: product.price,
        quantity,
        lineTotal,
      });
    }

    const insideDhakaFee = integer(block.insideDhakaFee, 70, 0, 10000);
    const outsideDhakaFee = integer(block.outsideDhakaFee, 130, 0, 10000);
    const shippingFee = zone === 'DHAKA' ? insideDhakaFee : outsideDhakaFee;
    const total = subtotal + shippingFee;
    const tracking = body?.tracking || {};

    const pageNote = [
      note,
      `Landing page: ${page.title} (${page.slug})`,
      text(tracking.source, 100) ? `UTM source: ${text(tracking.source, 100)}` : '',
      text(tracking.campaign, 120)
        ? `Campaign: ${text(tracking.campaign, 120)}`
        : '',
    ]
      .filter(Boolean)
      .join('\n')
      .slice(0, 1000);

    const created = await prisma.order.create({
      data: {
        orderNo: orderNo(),
        customerName,
        email: email || null,
        phone,
        address,
        city,
        area: zone === 'DHAKA' ? 'Dhaka Inside' : 'Dhaka Outside',
        note: pageNote,
        subtotal,
        shippingFee,
        total,
        items: {
          create: orderItems,
        },
      },
      select: {
        id: true,
        orderNo: true,
        subtotal: true,
        shippingFee: true,
        total: true,
        createdAt: true,
      },
    });

    // Analytics must never block a real order.
    try {
      await prisma.pageEvent.create({
        data: {
          pageId: page.id,
          pageSlug: page.slug,
          eventType: 'ORDER',
          label: created.orderNo,
          href: `/admin/orders`,
          source: text(tracking.source, 100) || 'direct',
          medium: text(tracking.medium, 100),
          campaign: text(tracking.campaign, 120),
          referrer: text(tracking.referrer, 500),
          path: `${page.pageType === 'LANDING' ? '/landing/' : '/page/'}${page.slug}`,
        },
      });
    } catch (eventError) {
      console.error('Page order analytics error:', eventError);
    }

    return Response.json(
      {
        ok: true,
        order: created,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Page order error:', error);

    return Response.json(
      {
        error: error?.message || 'Could not create order.',
      },
      { status: 500 }
    );
  }
}
