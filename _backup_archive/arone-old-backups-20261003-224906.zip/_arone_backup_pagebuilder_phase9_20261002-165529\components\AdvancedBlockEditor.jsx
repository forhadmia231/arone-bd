'use client';

import { useMemo } from 'react';
import styles from './PageBuilder.module.css';

const MAX_IMAGE_BYTES = 450 * 1024;
const IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/webp'];

function ColorField({ label, value, onChange }) {
  const safeValue = /^#[0-9a-fA-F]{6}$/.test(value || '')
    ? value
    : '#FFFFFF';

  return (
    <label>
      {label}
      <div className={styles.colorInputRow}>
        <input
          type="color"
          value={safeValue}
          onChange={(e) => onChange(e.target.value.toUpperCase())}
        />
        <input
          type="text"
          value={value || ''}
          onChange={(e) => onChange(e.target.value)}
          placeholder="#FFFFFF"
          maxLength="7"
        />
      </div>
    </label>
  );
}

function DesignControls({ block, field, hasButton = false }) {
  return (
    <details className={styles.designPanel}>
      <summary>Design & Spacing</summary>
      <div className={styles.designGrid}>
        <ColorField
          label="Background Color"
          value={block.backgroundColor || '#FFFFFF'}
          onChange={(value) => field('backgroundColor', value)}
        />
        <ColorField
          label="Text Color"
          value={block.textColor || '#17251C'}
          onChange={(value) => field('textColor', value)}
        />
        {hasButton && (
          <>
            <ColorField
              label="Button Color"
              value={block.buttonColor || '#235B37'}
              onChange={(value) => field('buttonColor', value)}
            />
            <ColorField
              label="Button Text"
              value={block.buttonTextColor || '#FFFFFF'}
              onChange={(value) => field('buttonTextColor', value)}
            />
          </>
        )}
        <label>
          Top Spacing (px)
          <input
            type="number"
            min="0"
            max="160"
            step="4"
            value={Number(block.paddingTop ?? 58)}
            onChange={(e) => field('paddingTop', Number(e.target.value))}
          />
        </label>
        <label>
          Bottom Spacing (px)
          <input
            type="number"
            min="0"
            max="160"
            step="4"
            value={Number(block.paddingBottom ?? 58)}
            onChange={(e) => field('paddingBottom', Number(e.target.value))}
          />
        </label>
      </div>
    </details>
  );
}

function AdvancedImageField({ label, value, onChange, onError, media = [] }) {
  function upload(event) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;

    if (!IMAGE_TYPES.includes(file.type)) {
      onError?.('Only PNG, JPG and WebP images are allowed.');
      return;
    }

    if (file.size > MAX_IMAGE_BYTES) {
      onError?.('Image is too large. Please optimize it to under 450 KB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      onError?.('');
      onChange(String(reader.result || ''));
    };
    reader.onerror = () => onError?.('Could not read the selected image.');
    reader.readAsDataURL(file);
  }

  const isDataUrl = String(value || '').startsWith('data:image/');

  return (
    <div className={styles.imageField}>
      <div className={styles.imageFieldHead}>
        <strong>{label}</strong>
        <span>WebP / PNG / JPG · max 450 KB</span>
      </div>

      <div className={styles.imageFieldControls}>
        <label className={styles.uploadButton}>
          Upload Image
          <input
            type="file"
            accept="image/png,image/jpeg,image/webp"
            onChange={upload}
          />
        </label>

        <input
          type="text"
          value={isDataUrl ? '' : value || ''}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Or paste https://... or /images/..."
        />

        {media.length > 0 && (
          <select
            value=""
            onChange={(e) => {
              if (e.target.value) onChange(e.target.value);
            }}
          >
            <option value="">Choose from Media Library...</option>
            {media.map((item) => (
              <option key={item.id} value={item.url}>
                {item.name}
              </option>
            ))}
          </select>
        )}

        {value && (
          <button
            type="button"
            className={styles.removeImageButton}
            onClick={() => onChange('')}
          >
            Remove
          </button>
        )}
      </div>

      {value && (
        <div className={styles.imagePreviewBox}>
          <img src={value} alt="Selected preview" />
          {isDataUrl && <span>Uploaded image ready to save</span>}
        </div>
      )}
    </div>
  );
}

export default function AdvancedBlockEditor({
  block,
  index,
  updateBlock,
  media = [],
  setError,
}) {
  const field = (name, value) => updateBlock(index, { [name]: value });

  const testimonials = useMemo(
    () => (Array.isArray(block.items) ? block.items : []),
    [block.items]
  );

  if (block.type === 'countdown') {
    return (
      <div className={styles.editorStack}>
        <div className={styles.formGrid}>
          <label className={styles.full}>
            Heading
            <input
              value={block.heading || ''}
              onChange={(e) => field('heading', e.target.value)}
            />
          </label>
          <label className={styles.full}>
            Message
            <textarea
              rows="3"
              value={block.text || ''}
              onChange={(e) => field('text', e.target.value)}
            />
          </label>
          <label>
            Offer Ends At
            <input
              type="datetime-local"
              value={block.endsAt || ''}
              onChange={(e) => field('endsAt', e.target.value)}
            />
          </label>
          <label>
            Expired Text
            <input
              value={block.expiredText || ''}
              onChange={(e) => field('expiredText', e.target.value)}
            />
          </label>
          <label>
            Button Text
            <input
              value={block.buttonText || ''}
              onChange={(e) => field('buttonText', e.target.value)}
            />
          </label>
          <label>
            Button URL
            <input
              value={block.buttonUrl || ''}
              onChange={(e) => field('buttonUrl', e.target.value)}
            />
          </label>
          <label className={styles.checkField}>
            <input
              type="checkbox"
              checked={block.showDays !== false}
              onChange={(e) => field('showDays', e.target.checked)}
            />
            Show days
          </label>
        </div>
        <DesignControls block={block} field={field} hasButton />
      </div>
    );
  }

  if (block.type === 'trust') {
    const items = Array.isArray(block.items) ? block.items : [];

    return (
      <div className={styles.editorStack}>
        <div className={styles.formGrid}>
          <label className={styles.full}>
            Section Heading
            <input
              value={block.heading || ''}
              onChange={(e) => field('heading', e.target.value)}
            />
          </label>
          <label>
            Columns
            <select
              value={Number(block.columns || 3)}
              onChange={(e) => field('columns', Number(e.target.value))}
            >
              <option value="2">2 columns</option>
              <option value="3">3 columns</option>
              <option value="4">4 columns</option>
            </select>
          </label>
        </div>

        {items.map((item, itemIndex) => (
          <div key={itemIndex} className={styles.faqEdit}>
            <input
              value={item.icon || ''}
              onChange={(e) =>
                field(
                  'items',
                  items.map((row, i) =>
                    i === itemIndex ? { ...row, icon: e.target.value } : row
                  )
                )
              }
              placeholder="Icon / emoji e.g. ✓"
            />
            <input
              value={item.title || ''}
              onChange={(e) =>
                field(
                  'items',
                  items.map((row, i) =>
                    i === itemIndex ? { ...row, title: e.target.value } : row
                  )
                )
              }
              placeholder="Title"
            />
            <textarea
              rows="2"
              value={item.text || ''}
              onChange={(e) =>
                field(
                  'items',
                  items.map((row, i) =>
                    i === itemIndex ? { ...row, text: e.target.value } : row
                  )
                )
              }
              placeholder="Short supporting text"
            />
            <button
              type="button"
              onClick={() =>
                field('items', items.filter((_, i) => i !== itemIndex))
              }
            >
              Remove
            </button>
          </div>
        ))}

        <button
          type="button"
          className={styles.smallButton}
          onClick={() =>
            field('items', [
              ...items,
              { icon: '✓', title: 'Trust point', text: 'Add a short benefit.' },
            ])
          }
        >
          + Add Trust Item
        </button>

        <DesignControls block={block} field={field} />
      </div>
    );
  }

  if (block.type === 'testimonials') {
    return (
      <div className={styles.editorStack}>
        <div className={styles.formGrid}>
          <label className={styles.full}>
            Section Heading
            <input
              value={block.heading || ''}
              onChange={(e) => field('heading', e.target.value)}
            />
          </label>
          <label>
            Columns
            <select
              value={Number(block.columns || 3)}
              onChange={(e) => field('columns', Number(e.target.value))}
            >
              <option value="1">1 column</option>
              <option value="2">2 columns</option>
              <option value="3">3 columns</option>
            </select>
          </label>
        </div>

        {testimonials.map((item, itemIndex) => (
          <div key={itemIndex} className={styles.faqEdit}>
            <input
              value={item.name || ''}
              onChange={(e) =>
                field(
                  'items',
                  testimonials.map((row, i) =>
                    i === itemIndex ? { ...row, name: e.target.value } : row
                  )
                )
              }
              placeholder="Customer name"
            />
            <select
              value={Number(item.rating || 5)}
              onChange={(e) =>
                field(
                  'items',
                  testimonials.map((row, i) =>
                    i === itemIndex
                      ? { ...row, rating: Number(e.target.value) }
                      : row
                  )
                )
              }
            >
              <option value="5">★★★★★ 5 stars</option>
              <option value="4">★★★★☆ 4 stars</option>
              <option value="3">★★★☆☆ 3 stars</option>
            </select>
            <textarea
              rows="3"
              value={item.text || ''}
              onChange={(e) =>
                field(
                  'items',
                  testimonials.map((row, i) =>
                    i === itemIndex ? { ...row, text: e.target.value } : row
                  )
                )
              }
              placeholder="Customer review"
            />
            <button
              type="button"
              onClick={() =>
                field(
                  'items',
                  testimonials.filter((_, i) => i !== itemIndex)
                )
              }
            >
              Remove
            </button>
          </div>
        ))}

        <button
          type="button"
          className={styles.smallButton}
          onClick={() =>
            field('items', [
              ...testimonials,
              { name: 'Customer', rating: 5, text: 'Write the review here.' },
            ])
          }
        >
          + Add Testimonial
        </button>

        <DesignControls block={block} field={field} />
      </div>
    );
  }

  if (block.type === 'video') {
    return (
      <div className={styles.editorStack}>
        <div className={styles.formGrid}>
          <label className={styles.full}>
            Heading
            <input
              value={block.heading || ''}
              onChange={(e) => field('heading', e.target.value)}
            />
          </label>
          <label className={styles.full}>
            Intro Text
            <textarea
              rows="3"
              value={block.text || ''}
              onChange={(e) => field('text', e.target.value)}
            />
          </label>
          <label className={styles.full}>
            YouTube / Vimeo URL
            <input
              value={block.videoUrl || ''}
              onChange={(e) => field('videoUrl', e.target.value)}
              placeholder="https://www.youtube.com/watch?v=..."
            />
          </label>
          <label>
            Video Width
            <select
              value={block.width || 'wide'}
              onChange={(e) => field('width', e.target.value)}
            >
              <option value="normal">Normal</option>
              <option value="wide">Wide</option>
              <option value="full">Full width</option>
            </select>
          </label>
        </div>
        <DesignControls block={block} field={field} />
      </div>
    );
  }

  if (block.type === 'gallery') {
    const images = Array.isArray(block.images) ? block.images : [];

    return (
      <div className={styles.editorStack}>
        <div className={styles.formGrid}>
          <label className={styles.full}>
            Section Heading
            <input
              value={block.heading || ''}
              onChange={(e) => field('heading', e.target.value)}
            />
          </label>
          <label>
            Columns
            <select
              value={Number(block.columns || 3)}
              onChange={(e) => field('columns', Number(e.target.value))}
            >
              <option value="2">2 columns</option>
              <option value="3">3 columns</option>
              <option value="4">4 columns</option>
            </select>
          </label>
          <label>
            Image Fit
            <select
              value={block.imageFit || 'cover'}
              onChange={(e) => field('imageFit', e.target.value)}
            >
              <option value="cover">Cover</option>
              <option value="contain">Contain</option>
            </select>
          </label>
        </div>

        {images.map((item, imageIndex) => (
          <div key={item.id || imageIndex} className={styles.editorStack}>
            <AdvancedImageField
              label={`Gallery Image ${imageIndex + 1}`}
              value={item.url || ''}
              onChange={(value) =>
                field(
                  'images',
                  images.map((row, i) =>
                    i === imageIndex ? { ...row, url: value } : row
                  )
                )
              }
              onError={setError}
              media={media}
            />
            <div className={styles.formGrid}>
              <label>
                Alt Text
                <input
                  value={item.alt || ''}
                  onChange={(e) =>
                    field(
                      'images',
                      images.map((row, i) =>
                        i === imageIndex ? { ...row, alt: e.target.value } : row
                      )
                    )
                  }
                />
              </label>
              <button
                type="button"
                className={styles.dangerButton}
                onClick={() =>
                  field('images', images.filter((_, i) => i !== imageIndex))
                }
              >
                Remove Image
              </button>
            </div>
          </div>
        ))}

        <button
          type="button"
          className={styles.smallButton}
          onClick={() =>
            field('images', [
              ...images,
              {
                id: `img_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
                url: '',
                alt: '',
              },
            ])
          }
        >
          + Add Gallery Image
        </button>

        <DesignControls block={block} field={field} />
      </div>
    );
  }

  return null;
}
