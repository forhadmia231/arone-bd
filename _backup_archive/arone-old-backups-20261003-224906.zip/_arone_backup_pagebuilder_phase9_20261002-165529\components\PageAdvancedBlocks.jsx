'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import styles from './PageAdvancedBlocks.module.css';

function safeColor(value, fallback) {
  const text = String(value || '').trim();
  return /^#[0-9a-fA-F]{6}$/.test(text) ? text : fallback;
}

function clamp(value, fallback, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, n));
}

function sectionStyle(block) {
  return {
    backgroundColor: safeColor(block.backgroundColor, '#FFFFFF'),
    color: safeColor(block.textColor, '#17251C'),
    paddingTop: clamp(block.paddingTop, 58, 0, 160),
    paddingBottom: clamp(block.paddingBottom, 58, 0, 160),
  };
}

function buttonStyle(block) {
  return {
    backgroundColor: safeColor(block.buttonColor, '#235B37'),
    color: safeColor(block.buttonTextColor, '#FFFFFF'),
  };
}

function parseDeadline(value) {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function useCountdown(value) {
  const deadline = useMemo(() => parseDeadline(value), [value]);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (!deadline) return undefined;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [deadline]);

  if (!deadline) {
    return { expired: false, days: 0, hours: 0, minutes: 0, seconds: 0, unset: true };
  }

  const diff = Math.max(0, deadline.getTime() - now);
  const totalSeconds = Math.floor(diff / 1000);

  return {
    expired: diff <= 0,
    unset: false,
    days: Math.floor(totalSeconds / 86400),
    hours: Math.floor((totalSeconds % 86400) / 3600),
    minutes: Math.floor((totalSeconds % 3600) / 60),
    seconds: totalSeconds % 60,
  };
}

function embedUrl(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';

  try {
    const url = new URL(raw);

    if (url.hostname === 'youtu.be') {
      const id = url.pathname.split('/').filter(Boolean)[0];
      return id ? `https://www.youtube.com/embed/${id}` : '';
    }

    if (url.hostname.includes('youtube.com')) {
      if (url.pathname.startsWith('/embed/')) return raw;
      const id = url.searchParams.get('v');
      return id ? `https://www.youtube.com/embed/${id}` : '';
    }

    if (url.hostname.includes('vimeo.com')) {
      const id = url.pathname.split('/').filter(Boolean).pop();
      return /^\d+$/.test(id || '') ? `https://player.vimeo.com/video/${id}` : '';
    }
  } catch {}

  return '';
}

function Countdown({ block, preview }) {
  const time = useCountdown(block.endsAt);

  const units = [
    ...(block.showDays !== false ? [['Days', time.days]] : []),
    ['Hours', time.hours],
    ['Minutes', time.minutes],
    ['Seconds', time.seconds],
  ];

  return (
    <section className={styles.section} style={sectionStyle(block)}>
      <div className={styles.inner}>
        {block.heading && <h2>{block.heading}</h2>}
        {block.text && <p className={styles.intro}>{block.text}</p>}

        {time.expired && !preview ? (
          <div className={styles.expired}>
            {block.expiredText || 'This offer has ended.'}
          </div>
        ) : (
          <div className={styles.countdown}>
            {units.map(([label, value]) => (
              <div className={styles.timeBox} key={label}>
                <strong>{String(value).padStart(2, '0')}</strong>
                <span>{label}</span>
              </div>
            ))}
          </div>
        )}

        {!block.endsAt && (
          <small className={styles.hint}>Set an offer end date in the editor.</small>
        )}

        {block.buttonText && (
          <Link
            href={block.buttonUrl || '#'}
            className={styles.button}
            style={buttonStyle(block)}
            data-page-cta={`Countdown: ${block.buttonText}`}
          >
            {block.buttonText}
          </Link>
        )}
      </div>
    </section>
  );
}

function Trust({ block }) {
  const items = Array.isArray(block.items) ? block.items : [];
  const columns = [2, 3, 4].includes(Number(block.columns))
    ? Number(block.columns)
    : 3;

  return (
    <section className={styles.section} style={sectionStyle(block)}>
      <div className={styles.inner}>
        {block.heading && <h2>{block.heading}</h2>}
        <div className={styles.grid} style={{ '--cols': columns }}>
          {items.map((item, index) => (
            <article className={styles.trustCard} key={index}>
              <span className={styles.trustIcon}>{item.icon || '✓'}</span>
              <strong>{item.title || 'Trust point'}</strong>
              {item.text && <p>{item.text}</p>}
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Testimonials({ block }) {
  const items = Array.isArray(block.items) ? block.items : [];
  const columns = [1, 2, 3].includes(Number(block.columns))
    ? Number(block.columns)
    : 3;

  return (
    <section className={styles.section} style={sectionStyle(block)}>
      <div className={styles.inner}>
        {block.heading && <h2>{block.heading}</h2>}
        <div className={styles.grid} style={{ '--cols': columns }}>
          {items.map((item, index) => {
            const rating = clamp(item.rating, 5, 1, 5);
            return (
              <article className={styles.testimonial} key={index}>
                <div className={styles.stars} aria-label={`${rating} out of 5 stars`}>
                  {'★'.repeat(rating)}{'☆'.repeat(5 - rating)}
                </div>
                <p>“{item.text || 'Customer review'}”</p>
                <strong>{item.name || 'Customer'}</strong>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function Video({ block }) {
  const src = embedUrl(block.videoUrl);
  const widthClass =
    block.width === 'full'
      ? styles.videoFull
      : block.width === 'normal'
        ? styles.videoNormal
        : styles.videoWide;

  return (
    <section className={styles.section} style={sectionStyle(block)}>
      <div className={styles.inner}>
        {block.heading && <h2>{block.heading}</h2>}
        {block.text && <p className={styles.intro}>{block.text}</p>}
        <div className={`${styles.videoWrap} ${widthClass}`}>
          {src ? (
            <iframe
              src={src}
              title={block.heading || 'Video'}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              loading="lazy"
            />
          ) : (
            <div className={styles.videoPlaceholder}>
              Add a valid YouTube or Vimeo URL.
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function Gallery({ block }) {
  const images = Array.isArray(block.images) ? block.images : [];
  const columns = [2, 3, 4].includes(Number(block.columns))
    ? Number(block.columns)
    : 3;
  const fit = block.imageFit === 'contain' ? 'contain' : 'cover';

  return (
    <section className={styles.section} style={sectionStyle(block)}>
      <div className={styles.inner}>
        {block.heading && <h2>{block.heading}</h2>}
        <div className={styles.gallery} style={{ '--cols': columns }}>
          {images.map((item, index) => (
            <figure key={item.id || index}>
              {item.url ? (
                <img
                  src={item.url}
                  alt={item.alt || ''}
                  loading="lazy"
                  style={{ objectFit: fit }}
                />
              ) : (
                <div className={styles.galleryPlaceholder}>Image</div>
              )}
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

export default function PageAdvancedBlocks({ block, preview = false }) {
  if (block.type === 'countdown') return <Countdown block={block} preview={preview} />;
  if (block.type === 'trust') return <Trust block={block} />;
  if (block.type === 'testimonials') return <Testimonials block={block} />;
  if (block.type === 'video') return <Video block={block} />;
  if (block.type === 'gallery') return <Gallery block={block} />;
  return null;
}
